// Changelog Module
const ChangelogModule = (function() {
    const changelog = [
        {
            version: '0.7',
            date: '02-05-26',
            summary: `MagicTap now has sound! Sounds contributed by Pitermach.
Added complete Spellcasting system with 8 spells and Spell Power regeneration.
Added Prestige Potential upgrades - unlock the power of your prestige level (10 tiers, 10% each).
Added Mana-Saturated upgrade chain continuation.
Fixed Runestone positioning and made them accessible buttons.
Improved screen reader announcements (reduced spam, clearer notifications).
Default volume now starts at 50%.
Various bug fixes and accessibility improvements.`
        },
        {
            version: '0.6',
            date: '02-01-26',
            summary: `Added 20+ achievements.
Added new flavor events.
Added new upgrades.
Added new buildings.
Added new possibilities for the Wishing Well.
Runestones can now appear to give potential buffs/debuffs. Pay attention to their color.
Added new Prestige upgrades, including plans for challenge modes.`
        },
        {
            version: '0.5',
            date: '01-31-26',
            summary: `Addressed MPS issue.
Added achievement-related upgrades, and fleshed out the achievement boost system.
Added more achievements, upgrades, and buildings.
Now you can get familiars, and we'll have a selector to display your favorite, as you unlock them.
Worked more on the Wishing Well.`
        },
        {
            version: '0.4',
            date: '01-30-26',
            summary: `Did a major overhaul including,
Tons of achievements
New upgrades
Slightly altered save system (you can save your option changes)
Added number formatting, and truncation for you monsters who don't want to hear long numbers.
2 new buildings
Setup for Magic Proficiency (boost to MPS based on achievements), including upgrades to further increase the mana production.
Improved accessibility.
Dismiss all notifications button.
Wishing Well setup. (Along with thoughts for future "mini-games.")
Bonus prestige upgrades.`
        },
        {
            version: '0.3',
            date: '01-29-26',
            summary: `Added prestige system.
Added new upgrades, and a new building.
Populated the Prestige Store with a single upgrade.`
        },
        {
            version: '0.1/0.2',
            date: '01-24-26/01-25-26',
            summary: `Initial release, and setup.
Made MagicTap with ClaudeCode.
Included the first buildings, and upgrades. Made achievements, and Game Navigation section.
Also includes save system.`
        }
    ];

    function getHTML() {
        return `
        <section id="changelog-panel" class="game-panel" hidden>
            <h2 id="changelog-heading" tabindex="-1">Changelog</h2>
            <div id="changelog-container" aria-labelledby="changelog-heading">
                <p>Current Version: <span id="current-version">${VERSION}</span></p>
                <div id="changelog-list"></div>
            </div>
        </section>`;
    }

    function renderChangelog() {
        const container = document.getElementById('changelog-list');
        if (!container) return;

        container.innerHTML = '';
        changelog.forEach(entry => {
            const entryDiv = document.createElement('div');
            entryDiv.className = 'changelog-entry';
            const summaryHtml = entry.summary.split('\n').map(line => `<p>• ${line}</p>`).join('');
            entryDiv.innerHTML = `
                <h3>V.${entry.version} <span class="changelog-date">${entry.date}</span></h3>
                ${summaryHtml}
            `;
            container.appendChild(entryDiv);
        });
    }

    function getChangelog() {
        return changelog;
    }

    return {
        getHTML,
        renderChangelog,
        getChangelog
    };
})();
